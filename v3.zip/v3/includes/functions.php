function loadSettings() {
    global $settings;
    $database = new Database();
    $db = $database->getConnection();
    $settingsObj = new SiteSettings($db);
    $settings = $settingsObj->getSettings();
    
   
    $defaults = [
        'site_title' => 'Mavi Güneş Sahaf',
        'site_description' => 'Ankara\'nın en güvenilir sahafı',
        'phone' => '0543 928 6154',
        'whatsapp' => '905439286154',
        'email' => 'sahfamavigunes@gmail.com',
        'address' => 'Çankaya, Ankara',
        'working_hours' => 'Pzt-Cmt: 09:00-18:00',
        'facebook_url' => '#',
        'instagram_url' => '#',
        'twitter_url' => '#',
        'experience_years' => '15',
        'total_books' => '50000',
        'happy_customers' => '5000',
        'satisfaction_rate' => '98',
        'hero_title' => 'Eski Kitaplarınızı En İyi Fiyatla Alıyoruz!',
        'hero_description' => 'WhatsApp\'tan fotoğraf gönderin, aynı gün adresinizden alalım! 15 yıllık deneyimimizle kitaplarınızı en adil şekilde değerlendiriyoruz.',
        'meta_keywords' => 'ankara sahaf, ikinci el kitap, kitap alım, antika kitap, eski kitap satış'
    ];
    
    foreach ($defaults as $key => $value) {
        if (!isset($settings[$key])) {
            $settings[$key] = $value;
        }
    }
    
    return $settings;
}

function getSetting($key) {
    global $settings;
    return isset($settings[$key]) ? $settings[$key] : '';
}

function formatPhone($phone) {
    return preg_replace('/(\d{4})(\d{3})(\d{2})(\d{2})/', '$1 $2 $3 $4', $phone);
}

function getWhatsAppLink($message = '') {
    $phone = getSetting('whatsapp');
    $defaultMessage = 'Merhaba, kitaplarım için değerlendirme yaptırmak istiyorum.';
    $message = $message ?: $defaultMessage;
    return "https://wa.me/{$phone}?text=" . urlencode($message);
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}