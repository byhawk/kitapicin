<?php
/**
 * MAVI GÜNEŞ SAHAF - KESİN ÇALIŞAN ÇÖZÜM
 * ======================================
 * Bu dosyayı index.php olarak kaydet ve test et
 */

// Hata raporlamayı aç
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Session başlat
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ==========================================
// 1. DATABASE SINIFI (EN ÜSTTE)
// ==========================================
class Database {
    private $host = 'localhost';
    private $db_name = 'palsosya_mavigunes';
    private $username = 'palsosya_mavi';
    private $password = 'MeRt06-+';
    private $charset = 'utf8mb4';
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=" . $this->charset;
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            // Veritabanı hatası varsa null döndür
            error_log("Database connection failed: " . $e->getMessage());
            return null;
        }
        return $this->conn;
    }
}

// ==========================================
// 2. SETTINGS SINIFI
// ==========================================
class SiteSettings {
    private $conn;
    private $table_name = "site_settings";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Ayarları getir
    public function getSettings() {
        // Veritabanı bağlantısı yoksa varsayılan ayarları döndür
        if (!$this->conn) {
            return $this->getDefaultSettings();
        }

        try {
            $query = "SELECT setting_key, setting_value FROM " . $this->table_name . " WHERE is_active = 1";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            $settings = [];
            while ($row = $stmt->fetch()) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
            
            // Eğer veritabanından hiç ayar gelmezse varsayılanları kullan
            if (empty($settings)) {
                return $this->getDefaultSettings();
            }
            
            // Eksik ayarları varsayılanlarla tamamla
            return array_merge($this->getDefaultSettings(), $settings);
            
        } catch(Exception $e) {
            error_log("Settings fetch failed: " . $e->getMessage());
            return $this->getDefaultSettings();
        }
    }

    // Varsayılan ayarlar
    private function getDefaultSettings() {
        return [
            'site_title' => 'Mavi Güneş Sahaf',
            'site_description' => 'Ankara\'nın en güvenilir sahafı',
            'phone' => '0543 928 6154',
            'whatsapp' => '905439286154',
            'email' => 'sahfamavigunes@gmail.com',
            'address' => 'Çankaya, Ankara',
            'working_hours' => 'Pzt-Cmt: 09:00-18:00',
            'facebook_url' => '#',
            'instagram_url' => '#',
            'twitter_url' => '#',
            'experience_years' => '15',
            'total_books' => '50000',
            'happy_customers' => '5000',
            'satisfaction_rate' => '98',
            'hero_title' => 'Eski Kitaplarınızı En İyi Fiyatla Alıyoruz!',
            'hero_description' => 'WhatsApp\'tan fotoğraf gönderin, aynı gün adresinizden alalım! 15 yıllık deneyimimizle kitaplarınızı en adil şekilde değerlendiriyoruz.',
            'meta_keywords' => 'ankara sahaf, ikinci el kitap, kitap alım, antika kitap, eski kitap satış'
        ];
    }

    // Tek ayar getir
    public function getSetting($key) {
        $settings = $this->getSettings();
        return isset($settings[$key]) ? $settings[$key] : null;
    }

    // Ayar güncelle
    public function updateSetting($key, $value) {
        if (!$this->conn) return false;
        
        try {
            $query = "UPDATE " . $this->table_name . " SET setting_value = ?, updated_at = NOW() WHERE setting_key = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $value);
            $stmt->bindParam(2, $key);
            return $stmt->execute();
        } catch(Exception $e) {
            error_log("Setting update failed: " . $e->getMessage());
            return false;
        }
    }

    // Yeni ayar ekle
    public function addSetting($key, $value, $description = '') {
        if (!$this->conn) return false;
        
        try {
            $query = "INSERT INTO " . $this->table_name . " (setting_key, setting_value, description, created_at) VALUES (?, ?, ?, NOW())";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $key);
            $stmt->bindParam(2, $value);
            $stmt->bindParam(3, $description);
            return $stmt->execute();
        } catch(Exception $e) {
            error_log("Setting add failed: " . $e->getMessage());
            return false;
        }
    }
}

// ==========================================
// 3. GLOBAL DEĞİŞKENLER VE FONKSİYONLAR
// ==========================================

// Global settings değişkeni
$settings = [];

// Ayarları yükle
function loadSettings() {
    global $settings;
    
    try {
        $database = new Database();
        $db = $database->getConnection();
        $settingsObj = new SiteSettings($db);
        $settings = $settingsObj->getSettings();
        
        return $settings;
    } catch (Exception $e) {
        error_log("LoadSettings error: " . $e->getMessage());
        
        // Hata durumunda varsayılan ayarları kullan
        $settings = [
            'site_title' => 'Mavi Güneş Sahaf',
            'site_description' => 'Ankara\'nın en güvenilir sahafı',
            'phone' => '0543 928 6154',
            'whatsapp' => '905439286154',
            'email' => 'sahfamavigunes@gmail.com',
            'address' => 'Çankaya, Ankara',
            'working_hours' => 'Pzt-Cmt: 09:00-18:00',
            'experience_years' => '15',
            'total_books' => '50000',
            'happy_customers' => '5000',
            'satisfaction_rate' => '98',
            'hero_title' => 'Eski Kitaplarınızı En İyi Fiyatla Alıyoruz!',
            'hero_description' => 'WhatsApp\'tan fotoğraf gönderin, aynı gün adresinizden alalım!',
            'meta_keywords' => 'ankara sahaf, ikinci el kitap, kitap alım'
        ];
        
        return $settings;
    }
}

function getSetting($key) {
    global $settings;
    return isset($settings[$key]) ? $settings[$key] : '';
}

function formatPhone($phone) {
    // Sadece rakamları al
    $cleaned = preg_replace('/[^0-9]/', '', $phone);
    
    // Türk telefon formatı: 0543 928 6154
    if (strlen($cleaned) == 11 && substr($cleaned, 0, 1) == '0') {
        return preg_replace('/(\d{4})(\d{3})(\d{2})(\d{2})/', '$1 $2 $3 $4', $cleaned);
    }
    
    return $phone;
}

function getWhatsAppLink($message = '') {
    $phone = getSetting('whatsapp');
    $defaultMessage = 'Merhaba, kitaplarım için değerlendirme yaptırmak istiyorum.';
    $message = $message ?: $defaultMessage;
    return "https://wa.me/{$phone}?text=" . urlencode($message);
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// ==========================================
// 4. AYARLARI YÜKLE
// ==========================================
try {
    $settings = loadSettings();
} catch (Exception $e) {
    die("HATA: Ayarlar yüklenemedi. " . $e->getMessage());
}

// ==========================================
// 5. URL ROUTING
// ==========================================
$request = $_SERVER['REQUEST_URI'];
$path = parse_url($request, PHP_URL_PATH);

// Alt klasör varsa path'i düzelt
$script_name = dirname($_SERVER['SCRIPT_NAME']);
if ($script_name !== '/' && $script_name !== '') {
    $path = str_replace($script_name, '', $path);
}
$path = trim($path, '/');

// Debug modu
if (isset($_GET['debug'])) {
    echo "<div style='background: #f0f0f0; padding: 20px; margin: 20px; border: 1px solid #ccc;'>";
    echo "<h3>🐛 DEBUG BILGILERI:</h3>";
    echo "<strong>REQUEST_URI:</strong> " . $_SERVER['REQUEST_URI'] . "<br>";
    echo "<strong>SCRIPT_NAME:</strong> " . $_SERVER['SCRIPT_NAME'] . "<br>";
    echo "<strong>PATH:</strong> " . $path . "<br>";
    echo "<strong>SETTINGS COUNT:</strong> " . count($settings) . "<br>";
    echo "<strong>SITE TITLE:</strong> " . getSetting('site_title') . "<br>";
    echo "<strong>PHONE:</strong> " . getSetting('phone') . "<br>";
    echo "</div>";
}

// Test sayfası
if (isset($_GET['test'])) {
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <title>Test Sayfası</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
            .success { background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 10px 0; }
            .info { background: #d1ecf1; border: 1px solid #b6d4db; padding: 15px; border-radius: 5px; margin: 10px 0; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #f2f2f2; }
        </style>
    </head>
    <body>
        <h1>🧪 Test Sayfası</h1>
        
        <div class="success">
            <h3>✅ Başarılı: Site Çalışıyor!</h3>
            <p>loadSettings() fonksiyonu tanımlı ve çalışıyor.</p>
        </div>

        <div class="info">
            <h3>📊 Site Ayarları:</h3>
            <table>
                <tr><th>Ayar</th><th>Değer</th></tr>
                <tr><td>Site Başlığı</td><td><?= getSetting('site_title') ?></td></tr>
                <tr><td>Telefon</td><td><?= formatPhone(getSetting('phone')) ?></td></tr>
                <tr><td>WhatsApp</td><td><?= getSetting('whatsapp') ?></td></tr>
                <tr><td>E-posta</td><td><?= getSetting('email') ?></td></tr>
                <tr><td>Adres</td><td><?= getSetting('address') ?></td></tr>
                <tr><td>Hero Başlık</td><td><?= getSetting('hero_title') ?></td></tr>
            </table>
        </div>

        <div class="info">
            <h3>🔗 Test Linkleri:</h3>
            <ul>
                <li><a href="/">Ana Sayfa</a></li>
                <li><a href="/about">Hakkımızda</a></li>
                <li><a href="/contact">İletişim</a></li>
                <li><a href="<?= getWhatsAppLink() ?>" target="_blank">WhatsApp Test</a></li>
                <li><a href="?debug=1">Debug Modu</a></li>
            </ul>
        </div>

        <div class="info">
            <h3>📱 WhatsApp Linki:</h3>
            <a href="<?= getWhatsAppLink() ?>" target="_blank" style="display: inline-block; background: #25D366; color: white; padding: 15px 25px; text-decoration: none; border-radius: 8px;">
                📱 WhatsApp ile Test Et
            </a>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// ==========================================
// 6. SAYFA ROUTING
// ==========================================
switch($path) {
    case '':
    case 'home':
        $current_page = 'home';
        $page_title = 'Ana Sayfa';
        $page_description = getSetting('hero_description');
        showHomePage();
        break;
        
    case 'about':
    case 'hakkimizda':
        $current_page = 'about';
        $page_title = 'Hakkımızda';
        $page_description = getSetting('experience_years') . ' yıldır Ankara\'da güvenilir sahaf hizmeti.';
        showAboutPage();
        break;
        
    case 'contact':
    case 'iletisim':
        $current_page = 'contact';
        $page_title = 'İletişim';
        $page_description = 'WhatsApp\'tan kitap fotoğrafı gönderin, hemen teklif alın!';
        showContactPage();
        break;
        
    case 'services':
    case 'hizmetler':
        $current_page = 'services';
        $page_title = 'Hizmetlerimiz';
        $page_description = 'Hangi türde kitapları alıyoruz? Tüm hizmetlerimizi inceleyin.';
        showServicesPage();
        break;
        
    default:
        show404Page();
        break;
}

// ==========================================
// 7. SAYFA FONKSİYONLARI
// ==========================================

function showBasicHeader($page_title) {
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $page_title ?> - <?= getSetting('site_title') ?></title>
        <meta name="description" content="<?= getSetting('site_description') ?>">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Inter', sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
            .navbar { background: white; padding: 15px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: fixed; top: 0; left: 0; right: 0; z-index: 1000; }
            .nav-container { display: flex; justify-content: space-between; align-items: center; }
            .nav-brand { font-size: 24px; font-weight: bold; color: #2D6B78; text-decoration: none; }
            .nav-links { display: flex; list-style: none; gap: 30px; }
            .nav-links a { text-decoration: none; color: #333; font-weight: 500; padding: 10px 15px; border-radius: 5px; transition: all 0.3s; }
            .nav-links a:hover { color: #2D6B78; background: #f8f9fa; }
            main { margin-top: 80px; min-height: calc(100vh - 200px); }
            .hero { padding: 100px 20px; text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
            .hero h1 { font-size: 3em; margin-bottom: 20px; }
            .hero p { font-size: 1.2em; margin-bottom: 30px; max-width: 600px; margin-left: auto; margin-right: auto; }
            .btn { display: inline-block; background: #25D366; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: 600; margin: 10px; transition: transform 0.3s; }
            .btn:hover { transform: translateY(-2px); }
            .btn-outline { background: transparent; border: 2px solid white; }
            .content { padding: 80px 20px; text-align: center; }
            .footer { background: #333; color: white; padding: 40px 0; text-align: center; }
            .footer h3 { margin-bottom: 20px; }
            .footer a { color: #25D366; text-decoration: none; margin: 0 15px; }
            .contact-info { margin: 20px 0; }
            
            @media (max-width: 768px) {
                .nav-links { display: none; }
                .hero h1 { font-size: 2em; }
                .hero { padding: 60px 20px; }
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <div class="container">
                <div class="nav-container">
                    <a href="/" class="nav-brand"><?= getSetting('site_title') ?></a>
                    <ul class="nav-links">
                        <li><a href="/">🏠 Ana Sayfa</a></li>
                        <li><a href="/about">📖 Hakkımızda</a></li>
                        <li><a href="/services">⚡ Hizmetler</a></li>
                        <li><a href="/contact">📞 İletişim</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <main>
    <?php
}

function showBasicFooter() {
    ?>
        </main>
        <footer class="footer">
            <div class="container">
                <h3><?= getSetting('site_title') ?></h3>
                <div class="contact-info">
                    <p>📞 Telefon: <?= formatPhone(getSetting('phone')) ?> | 📧 E-posta: <?= getSetting('email') ?></p>
                    <p>📍 Adres: <?= getSetting('address') ?> | ⏰ <?= getSetting('working_hours') ?></p>
                </div>
                <div style="margin-top: 20px;">
                    <a href="<?= getWhatsAppLink() ?>" target="_blank">
                        <i class="fab fa-whatsapp"></i> WhatsApp
                    </a>
                    <a href="tel:<?= getSetting('phone') ?>">
                        <i class="fas fa-phone"></i> Ara
                    </a>
                    <a href="mailto:<?= getSetting('email') ?>">
                        <i class="fas fa-envelope"></i> E-posta
                    </a>
                </div>
                <p style="margin-top: 20px; opacity: 0.8;">&copy; <?= date('Y') ?> <?= getSetting('site_title') ?>. Tüm hakları saklıdır.</p>
            </div>
        </footer>
    </body>
    </html>
    <?php
}

function showHomePage() {
    showBasicHeader('Ana Sayfa');
    ?>
    <section class="hero">
        <div class="container">
            <h1><?= getSetting('hero_title') ?></h1>
            <p><?= getSetting('hero_description') ?></p>
            <div>
                <a href="<?= getWhatsAppLink() ?>" target="_blank" class="btn">
                    <i class="fab fa-whatsapp"></i> WhatsApp ile İletişim
                </a>
                <a href="tel:<?= getSetting('phone') ?>" class="btn btn-outline">
                    <i class="fas fa-phone"></i> <?= formatPhone(getSetting('phone')) ?>
                </a>
            </div>
        </div>
    </section>
    
    <section class="content">
        <div class="container">
            <h2>🎯 Neden Bizi Seçmelisiniz?</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; margin-top: 40px;">
                <div>
                    <h3>⚡ Hızlı Hizmet</h3>
                    <p>Aynı gün içinde adresinizden alım yapıyoruz</p>
                </div>
                <div>
                    <h3>💰 En İyi Fiyat</h3>
                    <p>Piyasanın en uygun fiyatlarını garanti ediyoruz</p>
                </div>
                <div>
                    <h3>🏆 <?= getSetting('experience_years') ?> Yıl Deneyim</h3>
                    <p><?= number_format(getSetting('total_books')) ?>+ kitap aldık, <?= number_format(getSetting('happy_customers')) ?>+ müşteri memnun</p>
                </div>
            </div>
        </div>
    </section>
    <?php
    showBasicFooter();
}

function showAboutPage() {
    showBasicHeader('Hakkımızda');
    ?>
    <section class="content">
        <div class="container">
            <h1>📖 Hakkımızda</h1>
            <p style="font-size: 1.2em; margin: 30px 0; line-height: 1.8;">
                <?= getSetting('experience_years') ?> yıldır Ankara'da ikinci el kitap alım sektöründe hizmet vermekteyiz. 
                Bugüne kadar <?= number_format(getSetting('total_books')) ?>+ kitap alarak, çevreye katkıda bulunduk 
                ve <?= number_format(getSetting('happy_customers')) ?>+ müşterimizi mutlu ettik.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 40px; margin: 50px 0;">
                <div style="text-align: center; padding: 30px; background: #f8f9fa; border-radius: 10px;">
                    <h2 style="color: #2D6B78; margin-bottom: 10px;"><?= getSetting('experience_years') ?></h2>
                    <p>Yıl Deneyim</p>
                </div>
                <div style="text-align: center; padding: 30px; background: #f8f9fa; border-radius: 10px;">
                    <h2 style="color: #2D6B78; margin-bottom: 10px;"><?= number_format(getSetting('total_books')) ?>+</h2>
                    <p>Alınan Kitap</p>
                </div>
                <div style="text-align: center; padding: 30px; background: #f8f9fa; border-radius: 10px;">
                    <h2 style="color: #2D6B78; margin-bottom: 10px;"><?= number_format(getSetting('happy_customers')) ?>+</h2>
                    <p>Mutlu Müşteri</p>
                </div>
                <div style="text-align: center; padding: 30px; background: #f8f9fa; border-radius: 10px;">
                    <h2 style="color: #2D6B78; margin-bottom: 10px;"><?= getSetting('satisfaction_rate') ?>%</h2>
                    <p>Memnuniyet</p>
                </div>
            </div>

            <div style="margin-top: 50px;">
                <a href="<?= getWhatsAppLink() ?>" target="_blank" class="btn">
                    <i class="fab fa-whatsapp"></i> Bizimle İletişime Geçin
                </a>
            </div>
        </div>
    </section>
    <?php
    showBasicFooter();
}

function showContactPage() {
    showBasicHeader('İletişim');
    ?>
    <section class="content">
        <div class="container">
            <h1>📞 İletişim</h1>
            <p style="font-size: 1.2em; margin: 30px 0;">
                Kitaplarınız için değerlendirme yaptırmak istiyorsanız, en hızlı yöntem WhatsApp'tan fotoğraf göndermektir.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 40px; margin: 50px 0;">
                <div style="padding: 30px; border: 2px solid #25D366; border-radius: 10px; text-align: center;">
                    <h3 style="color: #25D366; margin-bottom: 20px;">
                        <i class="fab fa-whatsapp" style="font-size: 2em;"></i><br>
                        WhatsApp
                    </h3>
                    <p style="margin-bottom: 20px;">En hızlı ve kolay yöntem</p>
                    <p style="font-size: 1.2em; font-weight: bold; margin-bottom: 20px;">
                        <?= formatPhone(getSetting('phone')) ?>
                    </p>
                    <a href="<?= getWhatsAppLink() ?>" target="_blank" class="btn">
                        <i class="fab fa-whatsapp"></i> WhatsApp ile Mesaj Gönder
                    </a>
                </div>
                
                <div style="padding: 30px; border: 2px solid #2D6B78; border-radius: 10px; text-align: center;">
                    <h3 style="color: #2D6B78; margin-bottom: 20px;">
                        <i class="fas fa-phone" style="font-size: 2em;"></i><br>
                        Telefon
                    </h3>
                    <p style="margin-bottom: 20px;">Direkt görüşmek için</p>
                    <p style="font-size: 1.2em; font-weight: bold; margin-bottom: 20px;">
                        <?= formatPhone(getSetting('phone')) ?>
                    </p>
                    <a href="tel:<?= getSetting('phone') ?>" class="btn" style="background: #2D6B78;">
                        <i class="fas fa-phone"></i> Hemen Ara
                    </a>
                </div>
            </div>

            <div style="background: #f8f9fa; padding: 30px; border-radius: 10px; margin: 40px 0;">
                <h3 style="margin-bottom: 20px;">📍 Diğer İletişim Bilgileri</h3>
                <p><strong>📧 E-posta:</strong> <?= getSetting('email') ?></p>
                <p><strong>📍 Adres:</strong> <?= getSetting('address') ?></p>
                <p><strong>⏰ Çalışma Saatleri:</strong> <?= getSetting('working_hours') ?></p>
            </div>
        </div>
    </section>
    <?php
    showBasicFooter();
}

function showServicesPage() {
    showBasicHeader('Hizmetlerimiz');
    ?>
    <section class="content">
        <div class="container">
            <h1>⚡ Hizmetlerimiz</h1>
            <p style="font-size: 1.2em; margin: 30px 0;">
                Her türlü kitabınızı en uygun fiyatlarla değerlendiriyoruz.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin: 50px 0;">
                <div style="padding: 30px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #2D6B78;">
                    <h3 style="color: #2D6B78; margin-bottom: 15px;">
                        <i class="fas fa-book-open"></i> Roman & Edebiyat
                    </h3>
                    <p>Türk ve dünya edebiyatı, klasikler, çağdaş romanlar ve hikaye kitapları</p>
                    <p style="color: #25D366; font-weight: bold; margin-top: 15px;">15₺'den başlayan fiyatlar</p>
                </div>
                
                <div style="padding: 30px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #2D6B78;">
                    <h3 style="color: #2D6B78; margin-bottom: 15px;">
                        <i class="fas fa-graduation-cap"></i> Akademik & Ders Kitapları
                    </h3>
                    <p>Üniversite, lise ders kitapları, akademik yayınlar ve referans kaynakları</p>
                    <p style="color: #25D366; font-weight: bold; margin-top: 15px;">25₺'den başlayan fiyatlar</p>
                </div>
                
                <div style="padding: 30px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #2D6B78;">
                    <h3 style="color: #2D6B78; margin-bottom: 15px;">
                        <i class="fas fa-landmark"></i> Antika & Nadir Eserler
                    </h3>
                    <p>Eski basım kitaplar, antika eserler, el yazması kitaplar ve koleksiyon parçaları</p>
                    <p style="color: #25D366; font-weight: bold; margin-top: 15px;">100₺'den başlayan fiyatlar</p>
                </div>
                
                <div style="padding: 30px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #2D6B78;">
                    <h3 style="color: #2D6B78; margin-bottom: 15px;">
                        <i class="fas fa-child"></i> Çocuk & Gençlik
                    </h3>
                    <p>Çocuk kitapları, masallar, gençlik romanları ve eğitici yayınlar</p>
                    <p style="color: #25D366; font-weight: bold; margin-top: 15px;">10₺'den başlayan fiyatlar</p>
                </div>
                
                <div style="padding: 30px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #2D6B78;">
                    <h3 style="color: #2D6B78; margin-bottom: 15px;">
                        <i class="fas fa-newspaper"></i> Dergi & Çizgi Roman
                    </h3>
                    <p>Eski dergiler, çizgi romanlar, koleksiyon dergileri ve süreli yayınlar</p>
                    <p style="color: #25D366; font-weight: bold; margin-top: 15px;">5₺'den başlayan fiyatlar</p>
                </div>
                
                <div style="padding: 30px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #2D6B78;">
                    <h3 style="color: #2D6B78; margin-bottom: 15px;">
                        <i class="fas fa-palette"></i> Sanat & Kültür
                    </h3>
                    <p>Sanat tarihi, müzik, sinema, fotoğraf ve kültür kitapları</p>
                    <p style="color: #25D366; font-weight: bold; margin-top: 15px;">20₺'den başlayan fiyatlar</p>
                </div>
            </div>

            <div style="text-align: center; margin: 50px 0; padding: 40px; background: linear-gradient(135deg, #2D6B78, #4B9CAE); color: white; border-radius: 10px;">
                <h3 style="margin-bottom: 20px;">💰 Kitaplarınızın Değerini Merak Ediyor musunuz?</h3>
                <p style="margin-bottom: 30px;">WhatsApp'tan fotoğraf gönderin, ücretsiz değerlendirme yaptıralım!</p>
                <a href="<?= getWhatsAppLink() ?>" target="_blank" class="btn">
                    <i class="fab fa-whatsapp"></i> Hemen Değerlendirme Yaptır
                </a>
            </div>
        </div>
    </section>
    <?php
    showBasicFooter();
}

function show404Page() {
    http_response_code(404);
    showBasicHeader('404 - Sayfa Bulunamadı');
    ?>
    <section class="content" style="min-height: 60vh; display: flex; align-items: center; justify-content: center;">
        <div style="text-align: center;">
            <h1 style="font-size: 96px; color: #2D6B78; margin-bottom: 20px;">404</h1>
            <h2 style="margin-bottom: 20px;">Sayfa Bulunamadı</h2>
            <p style="margin-bottom: 40px; color: #666;">Aradığınız sayfa mevcut değil veya taşınmış olabilir.</p>
            <a href="/" class="btn" style="background: #2D6B78;">
                <i class="fas fa-home"></i> Ana Sayfaya Dön
            </a>
        </div>
    </section>
    <?php
    showBasicFooter();
}
?>